; Multiboot v1 header + minimal stub
; Provide a proper multiboot v1 header so GRUB recognizes the kernel.
; The header must appear within the first 8KB of the kernel image.

BITS 32

section .text
    align 4
    global multiboot_header
multiboot_header:
    dd 0x1BADB002          ; magic (multiboot)
    dd 0x00000003          ; flags: request memory info
    dd -(0x1BADB002 + 0x00000003) ; checksum

    global kernel_main
; No further stub here — the linker will set entry to kernel_main.

