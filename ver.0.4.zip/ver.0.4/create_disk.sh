#!/bin/bash
# Создаем пустой файл размером 100MB
dd if=/dev/zero of=disk.img bs=1M count=100

# Создаем таблицу разделов
fdisk disk.img << EOF
n
p
1
2048
204799
w
EOF

# Форматируем раздел (будет использоваться нашей простой ФС)