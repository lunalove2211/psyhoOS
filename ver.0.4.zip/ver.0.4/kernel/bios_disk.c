// BIOS INT 0x13 disk access - works with any disk type in QEMU
#include <stdint.h>
#include <stddef.h>
#include "console.h"

static uint8_t boot_drive;

int bios_disk_init(void) {
    // Get boot drive from BIOS (passed in DL by bootloader)
    asm volatile ("movb %%dl, %0" : "=r"(boot_drive));
    console_printf("bios_disk_init: boot_drive=0x%02x\n", boot_drive);
    return 0;
}

// Read sectors using INT 0x13 AH=02h (Read Sector)
// Simple CHS-based read, works with BIOS
int bios_disk_read(uint32_t lba, uint16_t sectors, void *buffer) {
    console_printf("bios_disk_read: lba=%u sectors=%u buf=%p\n", lba, sectors, buffer);
    
    // For simplicity in 32-bit mode, use BIOS INT 0x13 AH=02 (CHS read)
    // Convert LBA to CHS: C = LBA / (HPC * SPT), H = (LBA % (HPC * SPT)) / SPT, S = (LBA % SPT) + 1
    // Assume 63 sectors/track, 255 heads (standard for older systems)
    uint32_t hpc = 255, spt = 63;
    uint32_t c = lba / (hpc * spt);
    uint32_t h = (lba % (hpc * spt)) / spt;
    uint32_t s = (lba % spt) + 1;
    
    uint8_t err = 0;
    uint16_t seg = (uint16_t)((uint32_t)buffer >> 4);
    uint16_t off = (uint16_t)((uint32_t)buffer & 0x0F);
    
    // Real mode call via BIOS: AH=02, AL=sectors, CH=cylinder low, CL=sector+(cylinder high<<6),
    // DH=head, DL=drive, ES:BX = buffer
    // We'll use inline asm without segment register constraints
    asm volatile (
        ".code16gcc\n"
        "push %%bp\n"
        "mov %%sp, %%bp\n"
        "mov $0x02, %%ah\n"
        "mov %3, %%al\n"
        "mov %4, %%ch\n"
        "mov %5, %%cl\n"
        "mov %6, %%dh\n"
        "mov %1, %%dl\n"
        "mov %7, %%bx\n"
        "mov %2, %%es\n"
        "int $0x13\n"
        "setc %0\n"
        "pop %%bp\n"
        ".code32\n"
        : "=r"(err)
        : "r"(boot_drive), "r"(seg), "r"(sectors), "r"(c & 0xFF),
          "r"((c >> 2) | s), "r"(h), "r"(off)
        : "eax", "ebx", "ecx", "edx"
    );
    
    if (err) {
        console_printf("bios_disk_read: INT 0x13 failed\n");
        return -1;
    }
    
    console_printf("bios_disk_read: ok\n");
    return 0;
}

// Write sectors using INT 0x13 AH=03h (Write Sector)
int bios_disk_write(uint32_t lba, uint16_t sectors, const void *buffer) {
    console_printf("bios_disk_write: lba=%u sectors=%u buf=%p\n", lba, sectors, buffer);
    
    uint32_t hpc = 255, spt = 63;
    uint32_t c = lba / (hpc * spt);
    uint32_t h = (lba % (hpc * spt)) / spt;
    uint32_t s = (lba % spt) + 1;
    
    uint8_t err = 0;
    uint16_t seg = (uint16_t)((uint32_t)buffer >> 4);
    uint16_t off = (uint16_t)((uint32_t)buffer & 0x0F);
    
    asm volatile (
        ".code16gcc\n"
        "push %%bp\n"
        "mov %%sp, %%bp\n"
        "mov $0x03, %%ah\n"
        "mov %3, %%al\n"
        "mov %4, %%ch\n"
        "mov %5, %%cl\n"
        "mov %6, %%dh\n"
        "mov %1, %%dl\n"
        "mov %7, %%bx\n"
        "mov %2, %%es\n"
        "int $0x13\n"
        "setc %0\n"
        "pop %%bp\n"
        ".code32\n"
        : "=r"(err)
        : "r"(boot_drive), "r"(seg), "r"(sectors), "r"(c & 0xFF),
          "r"((c >> 2) | s), "r"(h), "r"(off)
        : "eax", "ebx", "ecx", "edx"
    );
    
    if (err) {
        console_printf("bios_disk_write: INT 0x13 failed\n");
        return -1;
    }
    
    console_printf("bios_disk_write: ok\n");
    return 0;
}
