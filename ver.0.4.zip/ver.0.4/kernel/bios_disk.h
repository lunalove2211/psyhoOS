#ifndef BIOS_DISK_H
#define BIOS_DISK_H

#include <stdint.h>

// BIOS INT 0x13 disk access functions
int bios_disk_init(void);
int bios_disk_read(uint32_t lba, uint16_t sectors, void *buffer);
int bios_disk_write(uint32_t lba, uint16_t sectors, const void *buffer);

#endif // BIOS_DISK_H
