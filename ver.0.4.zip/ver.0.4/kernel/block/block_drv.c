// Unified block device adapter for OS
#include "../drivers/block_interface.h"
#include <stdint.h>
#include <stddef.h>
extern void *memcpy(void *, const void *, size_t);

// Forward declarations for drivers
int nvme_init(void);
int nvme_read_sector(uint64_t lba, void *buf);
int nvme_write_sector(uint64_t lba, const void *buf);
int ahci_init(void);
int ahci_read_sector(uint64_t lba, void *buf);
int ahci_write_sector(uint64_t lba, const void *buf);
int ata_init(void);
int ata_read_sector(uint64_t lba, void *buf);
int ata_write_sector(uint64_t lba, const void *buf);

#define BLOCK_SECTOR_SIZE 512
#define RAMDISK_SIZE_SECTORS 204800
static uint8_t ramdisk[RAMDISK_SIZE_SECTORS * BLOCK_SECTOR_SIZE];
static int use_ramdisk = 0;
static uint64_t total_sectors = RAMDISK_SIZE_SECTORS;

static int (*drv_read)(uint64_t, void*) = NULL;
static int (*drv_write)(uint64_t, const void*) = NULL;

int block_init(void) {
    if (nvme_init() == 0) {
        drv_read = nvme_read_sector;
        drv_write = nvme_write_sector;
        // TODO: set total_sectors from NVMe identify
        use_ramdisk = 0;
        return 0;
    }
    if (ahci_init() == 0) {
        drv_read = ahci_read_sector;
        drv_write = ahci_write_sector;
        // TODO: set total_sectors from AHCI identify
        use_ramdisk = 0;
        return 0;
    }
    if (ata_init() == 0) {
        drv_read = ata_read_sector;
        drv_write = ata_write_sector;
        // TODO: set total_sectors from ATA identify
        use_ramdisk = 0;
        return 0;
    }
    // Fallback: RAMDISK
    drv_read = NULL;
    drv_write = NULL;
    use_ramdisk = 1;
    total_sectors = RAMDISK_SIZE_SECTORS;
    return 0;
}

int block_read(uint64_t lba, void *buf, uint32_t sectors) {
    if (use_ramdisk) {
        memcpy(buf, ramdisk + lba * BLOCK_SECTOR_SIZE, sectors * BLOCK_SECTOR_SIZE);
        return 0;
    }
    for (uint32_t i = 0; i < sectors; ++i) {
        if (drv_read == NULL || drv_read(lba + i, (uint8_t*)buf + i * BLOCK_SECTOR_SIZE) < 0)
            return -1;
    }
    return 0;
}

int block_write(uint64_t lba, const void *buf, uint32_t sectors) {
    if (use_ramdisk) {
        memcpy(ramdisk + lba * BLOCK_SECTOR_SIZE, buf, sectors * BLOCK_SECTOR_SIZE);
        return 0;
    }
    for (uint32_t i = 0; i < sectors; ++i) {
        if (drv_write == NULL || drv_write(lba + i, (const uint8_t*)buf + i * BLOCK_SECTOR_SIZE) < 0)
            return -1;
    }
    return 0;
}

uint64_t block_get_sectors(void) {
    return total_sectors;
}
