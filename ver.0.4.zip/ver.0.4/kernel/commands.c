/*
 * commands.c
 * Implementation of built-in commands: help, clear, exit, echo, date, ver, psycho, calc, ls, cat
 */

// Avoid relying on host's <stdint.h> in freestanding build; provide minimal types used here
typedef unsigned int uint32_t;
#include "console.h"
#include "rtc.h"
#include "fs.h"
/* shell readline prototype (implemented in shell.c) */
extern void shell_readline(char *buf, size_t buflen);
// В freestanding окружении избегаем зависимостей от стандартной libc headers;
// объявим маленький набор прототипов, которые мы предоставляем в kernel/libc.c
char *strtok(char *str, const char *delim);
int strcmp(const char *s1, const char *s2);
size_t strlen(const char *s);
void *memmove(void* dest, const void* src, size_t n);

// Виртуальная файловая система в памяти (пара тестовых файлов)
typedef struct { const char *name; const char *content; } vfile_t;
static vfile_t vfiles[] = {
    {"readme.txt", "PsychoZ-OS demo file\n"},
    {"notes.txt", "This is a test file in the in-memory virtual FS.\n"}
};

// Random phrases
static const char *phrases[] = {
    "ASTRA lab: analyze spacetime metrics before drawing conclusions.",
    "ASTRA lab: quantum branch scouting requires conservative assumptions.",
    "ASTRA lab: multiverse hypotheses are guided by symmetry and causality.",
    "ASTRA lab: observational signature beats speculative narrative.",
    "ASTRA lab: use entropy, not intuition, to compare parallel models.",
    "ASTRA lab: map geometry first, then interpret signal variance.",
    "ASTRA lab: keep the model minimal and the uncertainty explicit.",
    "ASTRA lab: cross-check any multiverse claim with relativity constraints."
};

// Простая псевдослучайная функция (LCG)
static uint32_t rng_state = 0x12345678;
static uint32_t rnd32() { rng_state = rng_state * 1664525 + 1013904223; return rng_state; }

// Утилиты парсинга
static void trim(char *s) {
    // убрать ведущие/хвостовые пробелы и табы
    char *p = s; while (*p == ' ' || *p == '\t') p++;
    memmove(s, p, strlen(p)+1);
    int len = strlen(s);
    while (len > 0 && (s[len-1] == ' ' || s[len-1] == '\t' || s[len-1] == '\r' || s[len-1] == '\n'))
        s[--len] = '\0';
}

// Прототип калькулятора
static const char *calc_p;
static long parse_expr();
static long parse_term();
static long parse_factor();

static void skip_spaces() { while (*calc_p == ' ') calc_p++; }

static long parse_expr() {
    long v = parse_term();
    for (;;) {
        skip_spaces();
        if (*calc_p == '+') { calc_p++; v += parse_term(); }
        else if (*calc_p == '-') { calc_p++; v -= parse_term(); }
        else break;
    }
    return v;
}

static long parse_term() {
    long v = parse_factor();
    for (;;) {
        skip_spaces();
        if (*calc_p == '*') { calc_p++; v *= parse_factor(); }
        else if (*calc_p == '/') { calc_p++; long d = parse_factor(); if (d) v /= d; }
        else break;
    }
    return v;
}

static long parse_number() {
    long sign = 1; if (*calc_p == '+') { calc_p++; } else if (*calc_p=='-') { calc_p++; sign=-1; }
    long v = 0; while (*calc_p >= '0' && *calc_p <= '9') { v = v*10 + (*calc_p - '0'); calc_p++; }
    return v * sign;
}

static long parse_factor() {
    skip_spaces();
    if (*calc_p == '(') { calc_p++; long v = parse_expr(); if (*calc_p==')') calc_p++; return v; }
    return parse_number();
}

// Команды
int command_dispatch(char *line) {
    trim(line);
    if (strlen(line) == 0) return 0;

    // Разделить на токены
    char *cmd = strtok(line, " ");
    if (!cmd) return 0;

    // поддержка команд с ведущим слэшем: "/CREATE", "/DIR" и т.д.
    if (cmd[0] == '/') cmd++;

    if (strcmp(cmd, "help") == 0) {
    console_printf("help - show list of commands\n");
    console_printf("clear - clear the screen\n");
    console_printf("exit - exit the OS (works if QEMU started with isa-debug-exit)\n");
    console_printf("echo <text> - print text\n");
    console_printf("date - show date/time (RTC)\n");
    console_printf("ver - show OS version\n");
    console_printf("info - show system identity and mission overview\n");
    console_printf("async <field> - run parallel-world reconnaissance probe\n");
    console_printf("scan_theory <topic> - evaluate theory relevance to multiverse search\n");
    console_printf("define <concept> - provide concise cosmology/quantum definition\n");
    console_printf("simple_model <system> - build a simplified cosmic model\n");
    console_printf("CREATE filename.txt - create and edit new file\n");
    console_printf("OPEN filename.txt - open and edit existing file\n");
    console_printf("SAVE - save changes to file\n");
    console_printf("DELETE filename.txt - delete file\n");
    console_printf("DIR - list files\n");
    } else if (strcmp(cmd, "clear") == 0) {
        console_clear();
    } else if (strcmp(cmd, "exit") == 0) {
        // Попытка корректно остановить QEMU через спецпорт (если запущен с isa-debug-exit)
        {
            unsigned short port = 0x501; /* match common isa-debug-exit iobase */
            asm volatile ("outb %%al, %%dx" : : "a"(0), "d"(port));
        }
        return 1; // сообщаем shell выйти
    } else if (strcmp(cmd, "echo") == 0) {
        char *rest = strtok(NULL, "");
        if (rest) console_printf("%s\n", rest); else console_printf("\n");
    } else if (strcmp(cmd, "date") == 0) {
        struct rtc_time t;
        rtc_get_time(&t);
        /* If RTC read looks invalid, fall back to a hardcoded current date (2025-11-08) */
        if (t.year < 2020 || t.year > 2100 || t.month < 1 || t.month > 12 || t.day < 1 || t.day > 31) {
            t.year = 2025; t.month = 11; t.day = 8;
            t.hour = 0; t.min = 0; t.sec = 0;
        }
        /* print padded numbers since console_printf has limited format support */
        char buf[32];
        /* YYYY-MM-DD HH:MM:SS */
        int p = 0;
        int y = t.year;
        buf[p++] = '0' + ((y/1000)%10);
        buf[p++] = '0' + ((y/100)%10);
        buf[p++] = '0' + ((y/10)%10);
        buf[p++] = '0' + (y%10);
        buf[p++] = '-';
        int m = t.month; buf[p++] = '0' + (m/10); buf[p++] = '0' + (m%10); buf[p++] = '-';
        int d = t.day; buf[p++] = '0' + (d/10); buf[p++] = '0' + (d%10); buf[p++] = ' ';
        int hr = t.hour; buf[p++] = '0' + (hr/10); buf[p++] = '0' + (hr%10); buf[p++] = ':';
        int mi = t.min; buf[p++] = '0' + (mi/10); buf[p++] = '0' + (mi%10); buf[p++] = ':';
        int se = t.sec; buf[p++] = '0' + (se/10); buf[p++] = '0' + (se%10);
        buf[p] = '\0';
        console_printf("Date/time: %s\n", buf);
    } else if (strcmp(cmd, "ver") == 0) {
        console_printf("%s\n", "ASTRA-OS v2.0 (PSYHOZ lab)");
    } else if (strcmp(cmd, "info") == 0) {
        console_printf("\nPSYHOZ lab - ASTRA-OS v2.0\n");
        console_printf("--------------------------------\n");
        console_printf("Specialized scientific intelligence system for cosmology and multiverse analysis.\n");
        console_printf("Focus: quantum-relativistic modeling, cosmic reconnaissance, and parallel-world scouting.\n");
        console_printf("This system is designed for qualitative assessment and hypothesis framing.\n\n");
        console_printf("Created by: PSYHOZ lab\n");
        console_printf("Version: ASTRA-OS v2.0\n");
        console_printf("Type 'help' to see available reconnaissance commands.\n\n");
    } else if (strcmp(cmd, "psycho") == 0) {
        uint32_t r = rnd32();
        const char *ph = phrases[r % (sizeof(phrases)/sizeof(phrases[0]))];
        console_printf("%s\n", ph);
    } else if (strcmp(cmd, "async") == 0) {
        char *field = strtok(NULL, " ");
        if (!field) {
            console_printf("Usage: async <field>\n");
        } else {
            console_printf("ASYNC reconnaissance initiated for: %s\n", field);
            console_printf("Theory: probing decoherence branches and metric perturbations.\n");
            console_printf("Equations: |Ψ⟩ = Σ c_i |φ_i⟩, ΔS ~ k_B ln Ω, R_{μν} - 1/2 g_{μν} R = 8πG/c^4 T_{μν}\n");
            console_printf("Assumptions: simplified symbolic model; no full numerical integration.\n");
            console_printf("Result: reconnaissance probe returns qualitative branch plausibility.\n");
            console_printf("Confidence: MEDIUM\n");
        }
    } else if (strcmp(cmd, "scan_theory") == 0) {
        char *topic = strtok(NULL, " ");
        if (!topic) {
            console_printf("Usage: scan_theory <topic>\n");
        } else {
            console_printf("SCAN_THEORY target: %s\n", topic);
            console_printf("Theory: assess possible multiverse relevance via entropy and metric stability.\n");
            console_printf("Equations: ΔS = k_B ln Ω, P ∼ exp(-S_E/ħ), g_{μν} δx^μ δx^ν\n");
            console_printf("Assumptions: contextual, not predictive; using standard cosmological heuristics.\n");
            console_printf("Result: topic aligned with multiverse reconnaissance.\n");
            console_printf("Confidence: LOW\n");
        }
    } else if (strcmp(cmd, "define") == 0) {
        char *concept = strtok(NULL, " ");
        if (!concept) {
            console_printf("Usage: define <concept>\n");
        } else {
            console_printf("DEFINE: %s\n", concept);
            console_printf("Description: core concept abstraction for cosmology and quantum branching.\n");
            console_printf("Assumptions: general scientific meaning in the context of parallel worlds.\n");
            console_printf("Confidence: MEDIUM\n");
        }
    } else if (strcmp(cmd, "simple_model") == 0) {
        char *system = strtok(NULL, " ");
        if (!system) {
            console_printf("Usage: simple_model <system>\n");
        } else {
            console_printf("SIMPLE_MODEL starting for: %s\n", system);
            console_printf("Theory: reduced-order model using approximate dynamics and observation constraints.\n");
            console_printf("Equations: E = mc^2, F = ma, H^2 ∼ 8πGρ/3\n");
            console_printf("Assumptions: coarse-grained, qualitative system description.\n");
            console_printf("Confidence: LOW\n");
        }
    } else if (strcmp(cmd, "calc") == 0) {
        char *expr = strtok(NULL, "");
        if (!expr) { console_printf("Usage: calc <expr>\n"); }
        else {
            calc_p = expr;
            long res = parse_expr();
            console_printf("= %ld\n", res);
        }
    } else if (strcmp(cmd, "ls") == 0) {
        for (size_t i=0;i<sizeof(vfiles)/sizeof(vfiles[0]);i++) console_printf("%s\n", vfiles[i].name);
    } else if (strcmp(cmd, "cat") == 0) {
        char *fn = strtok(NULL, " ");
        if (!fn) { console_printf("Usage: cat <file>\n"); }
        else {
            int found = 0;
            for (size_t i=0;i<sizeof(vfiles)/sizeof(vfiles[0]);i++) {
                if (strcmp(fn, vfiles[i].name) == 0) { console_printf("%s", vfiles[i].content); found=1; break; }
                }
                if (!found) console_printf("File not found: %s\n", fn);
        }
    } else if (strcmp(cmd, "CREATE") == 0) {
        char *filename = strtok(NULL, " ");
        if (!filename) {
            console_printf("Usage: CREATE filename.txt\n");
            return 0;
        }
        
        // Ensure filesystem is initialized
        console_printf("commands: CREATE -> fs_init\n");
        if (fs_init(0) < 0) {
            console_printf("Failed to initialize filesystem\n");
            return 0;
        }
        console_printf("commands: fs_init OK\n");
        
        // Check if file already exists
        if (fs_find_entry(filename)) {
            console_printf("Error: File already exists\n");
            return 0;
        }
        
        console_printf("commands: creating file '%s'\n", filename);
        if (fs_create(filename) < 0) {
            console_printf("Error creating file\n");
            return 0;
        }
        console_printf("commands: fs_create OK\n");
        
        console_printf("Enter text (press Enter to save):\n");
        char buf[1024];
        shell_readline(buf, sizeof(buf));
        
        console_printf("commands: writing file '%s' size=%u\n", filename, (unsigned)strlen(buf));
        if (fs_write(filename, buf, strlen(buf)) < 0) {
            console_printf("Error saving file content\n");
            return 0;
        }
        console_printf("commands: fs_write OK\n");
        
        console_printf("File saved successfully.\n");
    } else if (strcmp(cmd, "OPEN") == 0) {
        char *filename = strtok(NULL, " ");
        if (!filename) {
            console_printf("Usage: OPEN filename.txt\n");
            return 0;
        }
        char buf[1024];
        if (fs_read(filename, buf, sizeof(buf)) < 0) {
            console_printf("Error opening file\n");
            return 0;
        }
        console_printf("Current content:\n%s\n", buf);
        console_printf("Enter new text (press Enter to save):\n");
        shell_readline(buf, sizeof(buf));
        fs_write(filename, buf, strlen(buf));
        console_printf("File saved.\n");
    } else if (strcmp(cmd, "SAVE") == 0) {
        char *filename = strtok(NULL, " ");
        if (!filename) {
            console_printf("Usage: SAVE filename.txt\n");
            return 0;
        }

        if (fs_init(0) < 0) {
            console_printf("Failed to initialize filesystem\n");
            return 0;
        }
        // Если файла нет — создаём
        if (!fs_find_entry(filename)) {
            if (fs_create(filename) < 0) {
                console_printf("Error creating file\n");
                return 0;
            }
        }
        console_printf("Enter text to save (press Enter):\n");
        char buf[1024];
        shell_readline(buf, sizeof(buf));
        if (fs_write(filename, buf, strlen(buf)) < 0) {
            console_printf("Error saving file\n");
            return 0;
        }
        console_printf("File saved.\n");
    } else if (strcmp(cmd, "DELETE") == 0) {
        char *filename = strtok(NULL, " ");
        if (!filename) {
            console_printf("Usage: DELETE filename.txt\n");
            return 0;
        }
        if (fs_delete(filename) < 0) {
            console_printf("Error deleting file\n");
            return 0;
        }
        console_printf("File deleted.\n");
    } else if (strcmp(cmd, "DIR") == 0) {
        // Ensure filesystem is initialized
        if (fs_init(0) < 0) {
            console_printf("Failed to initialize filesystem\n");
            return 0;
        }
        fs_dir();
    } else {
        console_printf("Unknown command: %s\n", cmd);
    }


    return 0;
}
