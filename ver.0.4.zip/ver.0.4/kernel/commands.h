#ifndef COMMANDS_H
#define COMMANDS_H

int command_dispatch(char *line);

#endif // COMMANDS_H
