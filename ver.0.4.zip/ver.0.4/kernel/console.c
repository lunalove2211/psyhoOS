/*
 * console.c
 * Функции для вывода текста и минимального рендера UTF-8 в VGA text mode
 * и (частично) в framebuffer при наличии — учебная реализация.
 *
 * Код ориентирован на простоту и понятность, с подробными комментариями на русском.
 */

#include <stdarg.h>
#include <stdint.h>
#include <stddef.h>
#include "fonts/font8x16.h"

// I/O helpers for serial output
static inline void outb(unsigned short port, unsigned char val) {
    asm volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
}

static inline unsigned char inb(unsigned short port) {
    unsigned char ret;
    asm volatile ("inb %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

// Описываем примитивный консольный интерфейс.

// Если framebuffer недоступен, используем VGA text mode по адресу 0xB8000.
#define VGA_TEXT_BUF ((volatile uint16_t*)0xB8000)
#define VGA_WIDTH 80
#define VGA_HEIGHT 25

static int cursor_x = 0;
static int cursor_y = 0;
static uint8_t color = 0x07; // светло-серый на чёрном

// Небольшая таблица CP866/Unicode для кириллицы - упрощённая
// Мы реализуем декодер UTF-8 -> unicode, затем отображаем символы
//: Для простоты маппинга — при кодах в диапазоне ASCII используем напрямую,
//  а для русских букв (U+0410..U+044F) попытаемся отобразить приблизительным ASCII-заменителем.

// Низкоуровневые функции
static void move_cursor() {
    /* Обновляем аппаратный VGA курсор через порты 0x3D4/0x3D5.
       Это даст стандартный мигающий курсор в позицию (cursor_x,cursor_y).
    */
    unsigned short pos = cursor_y * VGA_WIDTH + cursor_x;
    outb(0x3D4, 0x0F);
    outb(0x3D5, (unsigned char)(pos & 0xFF));
    outb(0x3D4, 0x0E);
    outb(0x3D5, (unsigned char)((pos >> 8) & 0xFF));
}

void console_clear() {
    for (int y = 0; y < VGA_HEIGHT; y++) {
        for (int x = 0; x < VGA_WIDTH; x++) {
            VGA_TEXT_BUF[y*VGA_WIDTH + x] = (uint16_t)(' ') | ((uint16_t)color << 8);
        }
    }
    cursor_x = 0; cursor_y = 0;
    move_cursor();
}

void console_putc(char c) {
    if (c == '\n') {
        cursor_x = 0; cursor_y++;
    } else if (c == '\r') {
        cursor_x = 0;
    } else if (c == '\t') {
        cursor_x = (cursor_x + 8) & ~7;
    } else if (c == '\b') {
        if (cursor_x > 0) {
            cursor_x--;
            VGA_TEXT_BUF[cursor_y*VGA_WIDTH + cursor_x] = (uint16_t)(' ') | ((uint16_t)color << 8);
        } else if (cursor_y > 0) {
            cursor_y--;
            cursor_x = VGA_WIDTH - 1;
            VGA_TEXT_BUF[cursor_y*VGA_WIDTH + cursor_x] = (uint16_t)(' ') | ((uint16_t)color << 8);
        }
    } else {
        VGA_TEXT_BUF[cursor_y*VGA_WIDTH + cursor_x] = (uint16_t)(c) | ((uint16_t)color << 8);
        cursor_x++;
    }

    if (cursor_x >= VGA_WIDTH) { cursor_x = 0; cursor_y++; }
    if (cursor_y >= VGA_HEIGHT) {
        // прокрутка вверх на одну строку
        for (int y = 1; y < VGA_HEIGHT; y++) {
            for (int x = 0; x < VGA_WIDTH; x++) {
                VGA_TEXT_BUF[(y-1)*VGA_WIDTH + x] = VGA_TEXT_BUF[y*VGA_WIDTH + x];
            }
        }
        // очистить последнюю строку
        for (int x = 0; x < VGA_WIDTH; x++) VGA_TEXT_BUF[(VGA_HEIGHT-1)*VGA_WIDTH + x] = (uint16_t)(' ') | ((uint16_t)color << 8);
        cursor_y = VGA_HEIGHT - 1;
    }
    move_cursor();

    /* also write to serial COM1 (0x3F8) if present so we can capture logs in -serial */
    {
        unsigned short lsr_port = 0x3FD; /* Line Status Register */
        /* wait for transmitter empty */
        int i = 0;
        while (!(inb(lsr_port) & 0x20) && i < 10000) i++;
        outb(0x3F8, (unsigned char)c);
    }
}

void console_write(const char *s) {
    while (*s) {
        // Простейшая поддержка UTF-8: если байт < 0x80 — ASCII, иначе игнорируем многобайтовые и отображаем '?'
        unsigned char c = (unsigned char)*s;
        if (c < 0x80) {
            console_putc((char)c);
            s++;
        } else {
            // Попробуем распознать 2-байтовые формы для кириллицы (UTF-8): 0xD0 0x?? или 0xD1 0x??
            if ((unsigned char)s[0] == 0xD0 || (unsigned char)s[0] == 0xD1) {
                unsigned char hi = (unsigned char)s[0];
                unsigned char lo = (unsigned char)s[1];
                // Преобразуем в код Unicode
                uint16_t code = 0;
                if (hi == 0xD0) code = 0x0400 + lo; else code = 0x0440 + (lo - 0x80);
                // Простейшее отображение: заменить на похожую латинскую букву или '?'
                char repl = '?';
                // Для большинства распространённых букв сделаем простые замены
                if (code >= 0x0410 && code <= 0x042F) {
                    // А..Я -> A..Z (approx)
                    int idx = code - 0x0410;
                    if (idx < 26) repl = 'A' + idx;
                    else repl = '?';
                } else if (code >= 0x0430 && code <= 0x044F) {
                    int idx = code - 0x0430;
                    if (idx < 26) repl = 'a' + idx;
                    else repl = '?';
                }
                console_putc(repl);
                s += 2;
            } else {
                // непризнанный UTF-8 — пропускаем один байт
                console_putc('?');
                s++;
            }
        }
    }
}

void console_printf(const char *fmt, ...) {
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    int pos = 0;
    // Очень упрощённый vsnprintf — поддерживаем %s, %d, %ld, %u, %x, %p
    // также поддерживаем простую нулевую дополняющую ширину вида %02x, %03x, %08x
    for (const char *p = fmt; *p && pos < (int)sizeof(buf)-1; p++) {
        if (*p == '%') {
            p++;
            int long_flag = 0;
            // parse optional width with zero-padding like 02, 03, 08
            int width = 0; int zero_pad = 0;
            if (*p == 'l') { long_flag = 1; p++; }
            if (*p == '0') {
                zero_pad = 1;
                p++;
                while (*p >= '0' && *p <= '9') { width = width*10 + (*p - '0'); p++; }
            } else {
                while (*p >= '0' && *p <= '9') { width = width*10 + (*p - '0'); p++; }
            }

            if (*p == 's') {
                char *s = va_arg(ap, char*);
                for (; s && *s && pos < (int)sizeof(buf)-1; s++) buf[pos++] = *s;
            } else if (*p == 'd') {
                if (long_flag) {
                    long v = va_arg(ap, long);
                    char tmp[32]; int tp = 0;
                    if (v == 0) tmp[tp++] = '0';
                    int neg = 0; if (v < 0) { neg = 1; v = -v; }
                    while (v > 0 && tp < (int)sizeof(tmp)-1) { tmp[tp++] = '0' + (v % 10); v /= 10; }
                    if (neg) tmp[tp++] = '-';
                    while (tp>0 && pos < (int)sizeof(buf)-1) buf[pos++] = tmp[--tp];
                } else {
                    int v = va_arg(ap, int);
                    char tmp[32]; int tp = 0;
                    if (v == 0) tmp[tp++] = '0';
                    int neg = 0; if (v < 0) { neg = 1; v = -v; }
                    while (v > 0 && tp < (int)sizeof(tmp)-1) { tmp[tp++] = '0' + (v % 10); v /= 10; }
                    if (neg) tmp[tp++] = '-';
                    while (tp>0 && pos < (int)sizeof(buf)-1) buf[pos++] = tmp[--tp];
                }
            } else if (*p == 'u') {
                unsigned int v = va_arg(ap, unsigned int);
                char tmp[32]; int tp = 0;
                if (v == 0) tmp[tp++] = '0';
                while (v > 0 && tp < (int)sizeof(tmp)-1) { tmp[tp++] = '0' + (v % 10); v /= 10; }
                // apply width/zero_pad
                int pad = width - tp; while (pad-- > 0 && pos < (int)sizeof(buf)-1) buf[pos++] = zero_pad ? '0' : ' ';
                while (tp>0 && pos < (int)sizeof(buf)-1) buf[pos++] = tmp[--tp];
            } else if (*p == 'x' || *p == 'X') {
                unsigned int v = va_arg(ap, unsigned int);
                char tmp[32]; int tp = 0;
                const char *hex = (*p == 'x') ? "0123456789abcdef" : "0123456789ABCDEF";
                if (v == 0) tmp[tp++] = '0';
                while (v > 0 && tp < (int)sizeof(tmp)-1) { tmp[tp++] = hex[v & 0xF]; v >>= 4; }
                // padding
                int pad = width - tp; while (pad-- > 0 && pos < (int)sizeof(buf)-1) buf[pos++] = zero_pad ? '0' : ' ';
                while (tp>0 && pos < (int)sizeof(buf)-1) buf[pos++] = tmp[--tp];
            } else if (*p == 'p') {
                void *ptr = va_arg(ap, void*);
                unsigned long v = (unsigned long)ptr;
                // print 0x + hex
                if (pos < (int)sizeof(buf)-1) buf[pos++] = '0';
                if (pos < (int)sizeof(buf)-1) buf[pos++] = 'x';
                char tmp[32]; int tp = 0; const char *hex = "0123456789abcdef";
                if (v == 0) tmp[tp++] = '0';
                while (v > 0 && tp < (int)sizeof(tmp)-1) { tmp[tp++] = hex[v & 0xF]; v >>= 4; }
                while (tp>0 && pos < (int)sizeof(buf)-1) buf[pos++] = tmp[--tp];
            } else {
                // неизвестный формат — выводим буквально
                if (*p) buf[pos++] = *p;
            }
        } else {
            buf[pos++] = *p;
        }
    }
    buf[pos] = '\0';
    va_end(ap);
    console_write(buf);
}

void console_init() {
    // Ничего не делаем сейчас — VGA text mode используется по умолчанию
}
