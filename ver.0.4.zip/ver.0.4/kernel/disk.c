#include "disk.h"
#include <stddef.h>
#include "console.h"
#include <stdint.h>

// Low-level port I/O helpers
static inline void outb(uint16_t port, uint8_t val) {
    asm volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
}

static inline uint8_t inb(uint16_t port) {
    uint8_t val;
    asm volatile ("inb %1, %0" : "=a"(val) : "Nd"(port));
    return val;
}

static inline void outw(uint16_t port, uint16_t val) {
    asm volatile ("outw %0, %1" : : "a"(val), "Nd"(port));
}

static inline uint16_t inw(uint16_t port) {
    uint16_t val;
    asm volatile ("inw %1, %0" : "=a"(val) : "Nd"(port));
    return val;
}

// Small delay: read status port 4 times (400ns-ish) as per ATA spec
static void ata_io_delay(uint16_t base) {
    (void)inb(base + 7);
    (void)inb(base + 7);
    (void)inb(base + 7);
    (void)inb(base + 7);
}

// Wait until BSY cleared; return 0 on success, -1 on timeout
static int ata_wait_not_busy(uint16_t base, unsigned int timeout_ms) {
    // Simple polling loop with crude timeout
    unsigned int count = timeout_ms * 1000;
    while (count--) {
        uint8_t st = inb(base + 7);
        if (!(st & 0x80)) return 0; // BSY cleared
    }
    return -1;
}

// Wait until DRQ set or error
static int ata_wait_drq(uint16_t base, unsigned int timeout_ms) {
    unsigned int count = timeout_ms * 1000;
    while (count--) {
        uint8_t st = inb(base + 7);
        if (st & 0x08) return 0; // DRQ
        if (st & 0x01) return -1; // ERR
    }
    return -1;
}

// Определим номер диска, с которого загрузились (передается BIOS в dl)
static uint8_t boot_drive;

// Try to detect an ATA drive on the given base IO port
static int probe_ata_drive(uint16_t base, uint8_t device) {
    // Select drive and wait 400ns for drive select to complete
    outb(base + 6, device);
    ata_io_delay(base);
    
    // Software reset the controller
    outb(base + 7, 4);    // set SRST
    ata_io_delay(base);
    outb(base + 7, 0);    // clear SRST
    ata_io_delay(base);
    
    // Select the drive again after reset
    outb(base + 6, device);
    ata_io_delay(base);
    
    // Wait for BSY to clear from reset
    if (ata_wait_not_busy(base, 1000) < 0) {
        return -1;
    }
    
    // Now setup registers for IDENTIFY command
    outb(base + 2, 0);    // sector count = 0
    outb(base + 3, 0);    // sector number = 0
    outb(base + 4, 0);    // cylinder low = 0
    outb(base + 5, 0);    // cylinder high = 0
    outb(base + 7, 0xEC); // IDENTIFY command
    ata_io_delay(base);
    
    // Read status
    uint8_t status = inb(base + 7);
    if (status == 0xFF || status == 0x00) return -1; // No drive
    
    // Wait for BSY to clear
    unsigned int timeout = 1000;
    while ((inb(base + 7) & 0x80) && --timeout) {
        ata_io_delay(base);
    }
    if (!timeout) return -1;
    
    // Check status
    status = inb(base + 7);
    if (status & 0x01) return -1; // Error
    if (!(status & 0x08)) return -1; // No DRQ
    
    // Read identify data (we don't use it yet, but this confirms drive responds)
    uint16_t id_data[256];
    for (int i = 0; i < 256; i++) {
        id_data[i] = inw(base);
    }
    
    return 0; // Drive detected and responded
}

// Инициализация - определяем рабочие устройства
int disk_init(void) {
    // Получаем номер загрузочного диска из dl (установлен BIOS)
    asm volatile ("movb %%dl, %0" : "=r"(boot_drive));
    console_printf("disk_init: boot_drive=%d\n", (int)boot_drive);
    
    // Пробуем определить устройства на шине
    int found = 0;
    
    // Primary master/slave
    if (probe_ata_drive(0x1F0, 0xA0) == 0) {
        console_printf("disk_init: detected primary master\n");
        found++;
    }
    if (probe_ata_drive(0x1F0, 0xB0) == 0) {
        console_printf("disk_init: detected primary slave\n");
        found++;
    }
    
    // Secondary master/slave
    if (probe_ata_drive(0x170, 0xA0) == 0) {
        console_printf("disk_init: detected secondary master\n");
        found++;
    }
    if (probe_ata_drive(0x170, 0xB0) == 0) {
        console_printf("disk_init: detected secondary slave\n");
        found++;
    }
    
    console_printf("disk_init: found %d ATA devices\n", found);
    return found > 0 ? 0 : -1;
}

// Read single sector via PIO (LBA28) using given IO base and head select.
// base: data port base (0x1F0 for primary, 0x170 for secondary)
// head_select: 0xE0 for master, 0xF0 for slave (with LBA bits ORed)
static int ata_read_sector_lba28_io(uint16_t base, uint8_t head_select, uint32_t lba, void *buffer) {
    // Reset controller first
    outb(base + 2, 0);    // sector count = 0
    outb(base + 3, 0);    // sector number = 0
    outb(base + 4, 0);    // cylinder low = 0
    outb(base + 5, 0);    // cylinder high = 0
    outb(base + 6, 0xA0); // select master
    outb(base + 7, 0xEC); // identify command
    ata_io_delay(base);
    
    // Wait for BSY to clear and DRQ or ERR to set
    unsigned int timeout = 1000;
    while (timeout--) {
        uint8_t status = inb(base + 7);
        if (!(status & 0x80)) { // BSY cleared
            if (status & 0x08) break; // DRQ set - drive exists
            if (status & 0x01) return -1; // ERR set - no drive
        }
        if (timeout == 0) return -1;
    }
    
    // Now do the actual read
    outb(base + 6, head_select | ((lba >> 24) & 0x0F));
    outb(base + 2, 1); // sector count
    outb(base + 3, (uint8_t)(lba & 0xFF));
    outb(base + 4, (uint8_t)((lba >> 8) & 0xFF));
    outb(base + 5, (uint8_t)((lba >> 16) & 0xFF));
    ata_io_delay(base);
    outb(base + 7, 0x20); // READ SECTOR

    if (ata_wait_not_busy(base, 500) < 0) return -1;
    if (ata_wait_drq(base, 500) < 0) return -1;

    uint16_t *ptr = (uint16_t*)buffer;
    for (int i = 0; i < 256; i++) {
        ptr[i] = inw(base + 0);
    }
    return 0;
}

// Write single sector via PIO (LBA28). buffer must be 512 bytes.
static int ata_write_sector_lba28_io(uint16_t base, uint8_t head_select, uint32_t lba, const void *buffer) {
    outb(base + 6, head_select | ((lba >> 24) & 0x0F));
    outb(base + 2, 1); // sector count
    outb(base + 3, (uint8_t)(lba & 0xFF));
    outb(base + 4, (uint8_t)((lba >> 8) & 0xFF));
    outb(base + 5, (uint8_t)((lba >> 16) & 0xFF));
    ata_io_delay(base);
    outb(base + 7, 0x30); // WRITE SECTOR

    if (ata_wait_not_busy(base, 500) < 0) return -1;
    if (ata_wait_drq(base, 500) < 0) return -1;

    const uint16_t *ptr = (const uint16_t*)buffer;
    for (int i = 0; i < 256; i++) {
        outw(base + 0, ptr[i]);
    }

    // flush cache
    outb(base + 7, 0xE7);
    ata_wait_not_busy(base, 500);
    return 0;
}

// Read multiple sectors via PIO
// Try reading sectors by attempting common IO ports and drive selections.
static int ata_read_lba(uint32_t lba, uint16_t sectors, void *buffer) {
    uint8_t *buf = (uint8_t*)buffer;
    // candidate IO bases and head selects
    struct { uint16_t base; uint8_t head; const char *name; } candidates[4] = {
        {0x1F0, 0xE0, "primary master"},
        {0x1F0, 0xF0, "primary slave"},
        {0x170, 0xE0, "secondary master"},
        {0x170, 0xF0, "secondary slave"}
    };

    // Reorder candidates by boot_drive preference when possible
    int order[4] = {0,1,2,3};
    if (boot_drive >= 0x80) {
        // booted from HDD-like device: prefer primary master first
        order[0]=0; order[1]=1; order[2]=2; order[3]=3;
    } else if (boot_drive == 0) {
        // booted from CD/bootloader - prefer primary then secondary
        order[0]=0; order[1]=2; order[2]=1; order[3]=3;
    } else {
        // unknown - keep default
    }

    for (uint16_t i = 0; i < sectors; i++) {
        void *dst = buf + i * 512;
        int success = 0;
        for (int c = 0; c < 4; c++) {
            int idx = order[c];
            uint16_t base = candidates[idx].base;
            uint8_t head = candidates[idx].head;
            const char *name = candidates[idx].name;
            console_printf("ata_read_lba: trying %s (base=0x%03x head=0x%02x) lba=%u\n", name, base, head, (unsigned)(lba + i));
            if (ata_read_sector_lba28_io(base, head, lba + i, dst) == 0) {
                console_printf("ata_read_lba: success on %s\n", name);
                success = 1;
                break;
            } else {
                console_printf("ata_read_lba: fail on %s\n", name);
            }
        }
        if (!success) {
            console_printf("ata_read_lba: all attempts failed for lba=%u\n", (unsigned)(lba + i));
            return -1;
        }
    }
    return 0;
}

// Write multiple sectors via PIO by trying common ports/drives
static int ata_write_lba(uint32_t lba, uint16_t sectors, const void *buffer) {
    const uint8_t *buf = (const uint8_t*)buffer;
    struct { uint16_t base; uint8_t head; const char *name; } candidates[4] = {
        {0x1F0, 0xE0, "primary master"},
        {0x1F0, 0xF0, "primary slave"},
        {0x170, 0xE0, "secondary master"},
        {0x170, 0xF0, "secondary slave"}
    };
    int order[4] = {0,1,2,3};
    if (boot_drive >= 0x80) {
        order[0]=0; order[1]=1; order[2]=2; order[3]=3;
    } else if (boot_drive == 0) {
        order[0]=0; order[1]=2; order[2]=1; order[3]=3;
    }

    for (uint16_t i = 0; i < sectors; i++) {
        const void *src = buf + i * 512;
        int success = 0;
        for (int c = 0; c < 4; c++) {
            int idx = order[c];
            uint16_t base = candidates[idx].base;
            uint8_t head = candidates[idx].head;
            const char *name = candidates[idx].name;
            console_printf("ata_write_lba: trying %s (base=0x%03x head=0x%02x) lba=%u\n", name, base, head, (unsigned)(lba + i));
            if (ata_write_sector_lba28_io(base, head, lba + i, src) == 0) {
                console_printf("ata_write_lba: success on %s\n", name);
                success = 1;
                break;
            } else {
                console_printf("ata_write_lba: fail on %s\n", name);
            }
        }
        if (!success) {
            console_printf("ata_write_lba: all attempts failed for lba=%u\n", (unsigned)(lba + i));
            return -1;
        }
    }
    return 0;
}

// Проверка диапазона памяти
static int is_buffer_safe(const void *buffer, size_t size) {
    uintptr_t addr = (uintptr_t)buffer;
    // Для BIOS INT13 буфер может располагаться в низкой памяти (<1MB)
    // либо в заранее выделенной области (>=1MB && <32MB).
    if (addr < 0x100000) {
        // весь буфер должен помещаться в низкой памяти
        return (addr + size <= 0x100000);
    }
    return (addr >= 0x100000 && addr + size <= 0x2000000);  // Между 1MB и 32MB
}

// Чтение секторов через ATA PIO
int disk_read(uint32_t lba, uint16_t sectors, void *buffer) {
    // Проверка безопасности буфера
    if (!is_buffer_safe(buffer, sectors * 512)) {
        console_printf("disk_read: buffer not safe (ptr=0x%p size=%u)\n", buffer, (unsigned)(sectors*512));
        return -1;
    }
    // Use ATA PIO if possible
    if (ata_read_lba(lba, sectors, buffer) < 0) {
        console_printf("disk_read: ATA PIO read failed (lba=%u sectors=%u)\n", (unsigned)lba, (unsigned)sectors);
        return -1;
    }
    return 0;
}

// Запись секторов через ATA PIO
int disk_write(uint32_t lba, uint16_t sectors, const void *buffer) {
    // Проверка безопасности буфера
    if (!is_buffer_safe(buffer, sectors * 512)) {
        console_printf("disk_write: buffer not safe (ptr=0x%p size=%u)\n", buffer, (unsigned)(sectors*512));
        return -1;
    }
    // Use ATA PIO if possible
    if (ata_write_lba(lba, sectors, buffer) < 0) {
        console_printf("disk_write: ATA PIO write failed (lba=%u sectors=%u)\n", (unsigned)lba, (unsigned)sectors);
        return -1;
    }
    return 0;
}

// Поиск свободного места на диске
int disk_find_free_space(uint32_t *start_lba, uint32_t *size_sectors) {
    console_printf("disk_find_free_space: allocating space for filesystem\n");
    
    // Выделяем место для ФС без проверки MBR (работает везде)
    // Начинаем с сектора 2048 для выравнивания
    *start_lba = 2048;
    // 100MB (204800 секторов * 512 байт = 104857600 байт)
    *size_sectors = 204800;
    
    console_printf("disk_find_free_space: allocated LBA %u + %u sectors (%.1f MB)\n", 
                   *start_lba, *size_sectors, (*size_sectors * 512) / 1024.0 / 1024.0);
    
    return 0;
}
/*
 * ATA PIO disk driver
 * Clean implementation based on working backup. Provides basic
 * ATA LBA28 PIO read/write and MBR partition helper.
 */