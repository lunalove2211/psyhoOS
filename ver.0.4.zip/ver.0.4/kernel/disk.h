#ifndef DISK_H
#define DISK_H

#include <stdint.h>

// Инициализация работы с диском
int disk_init(void);

// Чтение секторов с диска (через INT 13h)
int disk_read(uint32_t lba, uint16_t sectors, void *buffer);

// Запись секторов на диск (через INT 13h)
int disk_write(uint32_t lba, uint16_t sectors, const void *buffer);

// Поиск свободного места на диске
int disk_find_free_space(uint32_t *start_lba, uint32_t *size_sectors);

#endif // DISK_H