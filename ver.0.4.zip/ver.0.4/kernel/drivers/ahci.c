// AHCI driver stub (PCI scan, BAR5 MMIO, port init, PRDT, DMA)
#include "block_interface.h"
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

int ahci_init(void) {
    // TODO: PCI scan for class 0x01, subclass 0x06, BAR5 MMIO, port init
    return -1; // Not implemented
}

int ahci_read_sector(uint64_t lba, void *buf) {
    // TODO: Implement real AHCI read
    return -1;
}

int ahci_write_sector(uint64_t lba, const void *buf) {
    // TODO: Implement real AHCI write
    return -1;
}
