// ATA PIO fallback driver for block interface
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include "block_interface.h"

#define ATA_PRIMARY_IO 0x1F0
#define ATA_PRIMARY_CTRL 0x3F6
#define ATA_SECTOR_SIZE 512

static int ata_detected = 0;

// 16-bit port I/O for ATA
static inline uint16_t inw(uint16_t port) {
    uint16_t ret;
    asm volatile ("inw %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}
static inline void outw(uint16_t port, uint16_t val) {
    asm volatile ("outw %0, %1" : : "a"(val), "Nd"(port));
}

static inline void outb(uint16_t port, uint8_t val) {
    asm volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
}
static inline uint8_t inb(uint16_t port) {
    uint8_t val;
    asm volatile ("inb %1, %0" : "=a"(val) : "Nd"(port));
    return val;
}
static inline void io_wait(void) {
    inb(0x80); inb(0x80); inb(0x80); inb(0x80);
}

static int ata_wait_ready(void) {
    for (int i = 0; i < 100000; ++i) {
        uint8_t status = inb(ATA_PRIMARY_IO + 7);
        if (!(status & 0x80)) return 0;
    }
    return -1;
}

int ata_init(void) {
    // Simple detection: try to read status
    uint8_t status = inb(ATA_PRIMARY_IO + 7);
    ata_detected = (status != 0xFF && status != 0x00);
    return ata_detected ? 0 : -1;
}

int ata_read_sector(uint64_t lba, void *buf) {
    if (!ata_detected) return -1;
    if (ata_wait_ready() < 0) return -1;
    outb(ATA_PRIMARY_IO + 6, 0xE0 | ((lba >> 24) & 0x0F));
    outb(ATA_PRIMARY_IO + 2, 1);
    outb(ATA_PRIMARY_IO + 3, (uint8_t)(lba & 0xFF));
    outb(ATA_PRIMARY_IO + 4, (uint8_t)((lba >> 8) & 0xFF));
    outb(ATA_PRIMARY_IO + 5, (uint8_t)((lba >> 16) & 0xFF));
    outb(ATA_PRIMARY_IO + 7, 0x20); // READ SECTOR
    if (ata_wait_ready() < 0) return -1;
    uint16_t *ptr = (uint16_t*)buf;
    for (int i = 0; i < ATA_SECTOR_SIZE / 2; ++i) ptr[i] = inw(ATA_PRIMARY_IO);
    return 0;
}

int ata_write_sector(uint64_t lba, const void *buf) {
    if (!ata_detected) return -1;
    if (ata_wait_ready() < 0) return -1;
    outb(ATA_PRIMARY_IO + 6, 0xE0 | ((lba >> 24) & 0x0F));
    outb(ATA_PRIMARY_IO + 2, 1);
    outb(ATA_PRIMARY_IO + 3, (uint8_t)(lba & 0xFF));
    outb(ATA_PRIMARY_IO + 4, (uint8_t)((lba >> 8) & 0xFF));
    outb(ATA_PRIMARY_IO + 5, (uint8_t)((lba >> 16) & 0xFF));
    outb(ATA_PRIMARY_IO + 7, 0x30); // WRITE SECTOR
    if (ata_wait_ready() < 0) return -1;
    const uint16_t *ptr = (const uint16_t*)buf;
    for (int i = 0; i < ATA_SECTOR_SIZE / 2; ++i) outw(ATA_PRIMARY_IO, ptr[i]);
    return 0;
}
