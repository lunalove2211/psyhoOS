#ifndef BLOCK_INTERFACE_H
#define BLOCK_INTERFACE_H
#include <stdint.h>

int block_init(void);
int block_read(uint64_t lba, void *buf, uint32_t sectors);
int block_write(uint64_t lba, const void *buf, uint32_t sectors);
uint64_t block_get_sectors(void);

#endif // BLOCK_INTERFACE_H
