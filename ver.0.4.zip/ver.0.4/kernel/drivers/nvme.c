// NVMe driver stub (PCI scan, MMIO, admin queue, IO queue)
#include "block_interface.h"
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

int nvme_init(void) {
    // TODO: PCI scan for class 0x01, subclass 0x08, MMIO BAR, queue setup
    return -1; // Not implemented
}

int nvme_read_sector(uint64_t lba, void *buf) {
    // TODO: Implement real NVMe read
    return -1;
}

int nvme_write_sector(uint64_t lba, const void *buf) {
    // TODO: Implement real NVMe write
    return -1;
}
