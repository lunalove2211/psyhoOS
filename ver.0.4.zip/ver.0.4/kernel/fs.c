#include "fs.h"
#include "console.h"
#include "rtc.h"
#include "disk.h"

// Прототипы функций из libc
void *memset(void *s, int c, size_t n);
void *memcpy(void *dest, const void *src, size_t n);
char *strncpy(char *dest, const char *src, size_t n);
int strcmp(const char *s1, const char *s2);
int memcmp(const void *s1, const void *s2, size_t n);

// Буфер для кэширования блоков
static uint8_t fs_buffer[8192];  // 8KB статический буфер для безопасности
static uint32_t fs_start_lba;     // Начальный сектор раздела
static uint32_t fs_total_sectors; // Общий размер в секторах
static struct fs_superblock *superblock = NULL;
// Если настоящий BIOS-диск недоступен, используем RAM-FS
static int ramfs = 0;  // Отключаем RAM-FS режим для использования реального диска
// Предоставим область для блоков в памяти (256 блоков * 4KB = 1MB)
static uint8_t ram_blocks[256][FS_BLOCK_SIZE];
// Простая таблица содержимого файлов для RAM-FS (максимум 64 файла, 4092 байта данных)
static uint8_t ram_file_data[64][4092];

// Получить запись файла по имени
struct fs_entry *fs_find_entry(const char *name) {
    struct fs_entry *entries = (struct fs_entry*)(fs_buffer + FS_BLOCK_SIZE);
    for (int i = 0; i < 64; i++) {  // Максимум 64 файла для примера
        if (entries[i].flags && strcmp(entries[i].name, name) == 0) {
            return &entries[i];
        }
    }
    return NULL;
}

// Найти свободную запись для нового файла
static struct fs_entry *fs_get_free_entry(void) {
    struct fs_entry *entries = (struct fs_entry*)(fs_buffer + FS_BLOCK_SIZE);
    for (int i = 0; i < 64; i++) {
        if (!entries[i].flags) {
            return &entries[i];
        }
    }
    return NULL;
}

// Глобальный флаг, указывающий что ФС инициализирована
static int fs_initialized = 0;

// Инициализация ФС
int fs_init(uint32_t size_mb) {
    // Проверяем, не инициализирована ли уже ФС
    if (fs_initialized) {
        return 0;
    }
    console_printf("fs_init: start\n");
    
    // Очищаем буфер перед использованием
    memset(fs_buffer, 0, sizeof(fs_buffer));
    /* Если настроен RAM-FS — сразу инициализируем его */
    if (ramfs) {
        fs_start_lba = 0;
        fs_total_sectors = (256 * FS_BLOCK_SIZE) / 512; // емкость ram_blocks
        memset(fs_buffer, 0, 512);
        superblock = (struct fs_superblock*)fs_buffer;
        superblock->magic = FS_MAGIC;
        superblock->blocks = 256;
        superblock->free_block = 2;
        superblock->block_size = FS_BLOCK_SIZE;
        memset(fs_buffer + FS_BLOCK_SIZE, 0, FS_BLOCK_SIZE);
        fs_initialized = 1;
        console_printf("fs_init: RAM-FS forced (blocks=%u)\n", superblock->blocks);
        return 0;
    }

    /* Для реального диска: попробуем найти/создать раздел (disk_find_free_space)
       Если не получилось — делаем fallback на RAM-FS, иначе продолжаем с найденными LBA. */
    console_printf("fs_init: probing disk for partition\n");
    if (disk_find_free_space(&fs_start_lba, &fs_total_sectors) < 0) {
        console_printf("fs_init: Failed to find or create partition - falling back to RAM-FS\n");
        /* включаем RAM-FS динамически */
        ramfs = 1;
        fs_start_lba = 0;
        fs_total_sectors = (256 * FS_BLOCK_SIZE) / 512;
        memset(fs_buffer, 0, 512);
        superblock = (struct fs_superblock*)fs_buffer;
        superblock->magic = FS_MAGIC;
        superblock->blocks = 256;
        superblock->free_block = 2;
        superblock->block_size = FS_BLOCK_SIZE;
        memset(fs_buffer + FS_BLOCK_SIZE, 0, FS_BLOCK_SIZE);
        fs_initialized = 1;
        console_printf("fs_init: RAM-FS fallback (blocks=%u)\n", superblock->blocks);
        return 0;
    }

    console_printf("fs_init: partition start_lba=%u total_sectors=%u\n", fs_start_lba, fs_total_sectors);

    // Читаем суперблок
    if (disk_read(fs_start_lba, 1, fs_buffer) < 0) {
        console_printf("fs_init: disk read failed, falling back to RAM-FS\n");
        /* включаем RAM-FS динамически */
        ramfs = 1;
        fs_start_lba = 0;
        fs_total_sectors = (256 * FS_BLOCK_SIZE) / 512;
        memset(fs_buffer, 0, 512);
        superblock = (struct fs_superblock*)fs_buffer;
        superblock->magic = FS_MAGIC;
        superblock->blocks = 256;
        superblock->free_block = 2;
        superblock->block_size = FS_BLOCK_SIZE;
        memset(fs_buffer + FS_BLOCK_SIZE, 0, FS_BLOCK_SIZE);
        fs_initialized = 1;
        console_printf("fs_init: RAM-FS fallback (blocks=%u)\n", superblock->blocks);
        return 0;
    }

    superblock = (struct fs_superblock*)fs_buffer;
    console_printf("fs_init: superblock magic=0x%08x\n", superblock->magic);
    
    // Если это новый раздел - инициализируем ФС
    if (superblock->magic != FS_MAGIC) {
        console_printf("fs_init: initializing new filesystem\n");
        // Очищаем суперблок
        memset(fs_buffer, 0, 512);
        
        // Инициализируем суперблок
        superblock->magic = FS_MAGIC;
        superblock->blocks = fs_total_sectors * 512 / FS_BLOCK_SIZE;
        superblock->free_block = 2;  // После суперблока и таблицы файлов
        superblock->block_size = FS_BLOCK_SIZE;
        
        console_printf("fs_init: writing superblock (magic=0x%08x blocks=%u free_block=%u block_size=%u)\n",
                      superblock->magic, superblock->blocks, superblock->free_block, superblock->block_size);
        
        // Записываем суперблок на диск
        if (disk_write(fs_start_lba, 1, fs_buffer) < 0) {
            console_printf("fs_init: Failed to write superblock\n");
            return -1;
        }
        
        // Верифицируем суперблок
        uint8_t verify[512];
        if (disk_read(fs_start_lba, 1, verify) < 0) {
            console_printf("fs_init: Failed to verify superblock\n");
            return -1;
        }
        if (memcmp(fs_buffer, verify, 512) != 0) {
            console_printf("fs_init: Superblock verification failed\n");
            return -1;
        }
        
        console_printf("fs_init: writing file table\n");
        // Очищаем таблицу файлов
        memset(fs_buffer, 0, FS_BLOCK_SIZE);
        if (disk_write(fs_start_lba + 1, FS_BLOCK_SIZE/512, fs_buffer) < 0) {
            console_printf("fs_init: Failed to write file table\n");
            return -1;
        }
        
        console_printf("fs_init: filesystem initialized successfully\n");
    }
    
    // Читаем таблицу файлов в буфер
    if (!ramfs) {
        console_printf("fs_init: loading file table\n");
        if (disk_read(fs_start_lba + 1, FS_BLOCK_SIZE/512, fs_buffer + FS_BLOCK_SIZE) < 0) {
            console_printf("fs_init: Failed to load file table\n");
            return -1;
        }
    }

    fs_initialized = 1;
    asm volatile("sti");  // Включаем прерывания обратно
    console_printf("fs_init: initialization complete\n");
    return 0;
}

// Создать новый файл
int fs_create(const char *name) {
    console_printf("fs_create: creating '%s'\n", name);
    
    if (!fs_initialized) {
        console_printf("fs_create: filesystem not initialized\n");
        if (fs_init(0) < 0) {
            console_printf("fs_create: failed to initialize filesystem\n");
            return -1;
        }
    }

    if (!superblock || superblock->magic != FS_MAGIC) {
        console_printf("fs_create: superblock invalid (magic=0x%08x)\n", 
            superblock ? superblock->magic : 0);
        return -1;
    }

    // Перечитаем таблицу файлов с диска
    if (!ramfs) {
        console_printf("fs_create: reading file table\n");
        if (disk_read(fs_start_lba + 1, FS_BLOCK_SIZE/512, fs_buffer + FS_BLOCK_SIZE) < 0) {
            console_printf("fs_create: failed to read file table\n");
            return -1;
        }
    }
    
    // Проверить, не существует ли файл
    if (fs_find_entry(name)) {
        console_printf("fs_create: file exists '%s'\n", name);
        return -1;
    }
    
    // Найти свободную запись
    struct fs_entry *entry = fs_get_free_entry();
    if (!entry) {
        console_printf("fs_create: no free entries available\n");
        return -1;
    }
    
    // Заполнить запись
    memset(entry, 0, sizeof(*entry));
    strncpy(entry->name, name, FS_MAX_FILENAME-1);
    entry->size = 0;
    struct rtc_time t;
    rtc_get_time(&t);
    entry->created = ((uint64_t)t.year << 40) | ((uint64_t)t.month << 32) |
                    ((uint64_t)t.day << 24) | (t.hour << 16) | (t.min << 8) | t.sec;
    entry->flags = 1;  // Файл используется

    // Записать обновленную таблицу файлов
    if (!ramfs) {
        console_printf("fs_create: writing updated file table\n");
        if (disk_write(fs_start_lba + 1, FS_BLOCK_SIZE/512, fs_buffer + FS_BLOCK_SIZE) < 0) {
            console_printf("fs_create: failed to write file table\n");
            return -1;
        }

        // Сохранить суперблок (на случай, если метаданные изменятся)
        console_printf("fs_create: writing superblock\n");
        if (disk_write(fs_start_lba, 1, fs_buffer) < 0) {
            console_printf("fs_create: failed to write superblock\n");
            return -1;
        }

        // Верифицируем таблицу файлов
        uint8_t verify[FS_BLOCK_SIZE];
        if (disk_read(fs_start_lba + 1, FS_BLOCK_SIZE/512, verify) < 0) {
            console_printf("fs_create: failed to verify file table\n");
            return -1;
        }
        if (memcmp(fs_buffer + FS_BLOCK_SIZE, verify, FS_BLOCK_SIZE) != 0) {
            console_printf("fs_create: file table verification failed\n");
            return -1;
        }
        console_printf("fs_create: file table verified\n");
    }
    
    console_printf("fs_create: file '%s' created successfully\n", name);    
    return 0;
}

// Удалить файл
int fs_delete(const char *name) {
    // Обновим таблицу файлов в памяти (чтобы fs_find_entry работал с актуальными данными)
    if (!ramfs) {
        if (disk_read(fs_start_lba + 1, FS_BLOCK_SIZE/512, fs_buffer + FS_BLOCK_SIZE) < 0) {
            console_printf("fs_delete: failed to read file table\n");
            return -1;
        }
    }

    struct fs_entry *entry = fs_find_entry(name);
    if (!entry) return -1;

    // Освободить блоки данных
    uint32_t block = entry->first_block;
    if (ramfs) {
        struct fs_entry *entries = (struct fs_entry*)(fs_buffer + FS_BLOCK_SIZE);
        int idx = entry - entries;
        if (idx >= 0 && idx < 64) memset(ram_file_data[idx], 0, sizeof(ram_file_data[idx]));
    } else {
        // Проходим по цепочке блоков, очищаем их на диске
        uint32_t sectors_per_block = FS_BLOCK_SIZE / 512;
        while (block) {
            // Прочитаем блок
            if (disk_read(fs_start_lba + block * sectors_per_block, sectors_per_block, fs_buffer + FS_BLOCK_SIZE) < 0) {
                console_printf("fs_delete: failed to read block %u\n", block);
                return -1;
            }
            struct fs_block *b = (struct fs_block*)(fs_buffer + FS_BLOCK_SIZE);
            uint32_t next = b->next;
            memset(b, 0, FS_BLOCK_SIZE);
            // Запишем очищенный блок обратно
            if (disk_write(fs_start_lba + block * sectors_per_block, sectors_per_block, fs_buffer + FS_BLOCK_SIZE) < 0) {
                console_printf("fs_delete: failed to write cleared block %u\n", block);
                return -1;
            }
            block = next;
        }
    }

    // Очистить запись и записать обновлённую таблицу
    memset(entry, 0, sizeof(*entry));
    if (!ramfs) {
        if (disk_write(fs_start_lba + 1, FS_BLOCK_SIZE/512, fs_buffer + FS_BLOCK_SIZE) < 0) {
            console_printf("fs_delete: failed to write file table after delete\n");
            return -1;
        }
        if (disk_write(fs_start_lba, 1, fs_buffer) < 0) {
            console_printf("fs_delete: failed to write superblock after delete\n");
            return -1;
        }
    }
    return 0;
}

// Записать данные в файл
int fs_write(const char *name, const void *data, uint32_t size) {
    if (!fs_initialized) {
        if (fs_init(0) < 0) {
            console_printf("Failed to initialize filesystem\n");
            return -1;
        }
    }
    console_printf("fs_write: name='%s' size=%u\n", name, (unsigned)size);

    // Читаем таблицу файлов с диска (если не RAM-FS)
    if (!ramfs) {
        if (disk_read(fs_start_lba + 1, FS_BLOCK_SIZE/512, fs_buffer + FS_BLOCK_SIZE) < 0) {
            console_printf("Failed to read file table\n");
            return -1;
        }
    }
    
    struct fs_entry *entry = fs_find_entry(name);
    if (!entry) { console_printf("fs_write: entry not found '%s'\n", name); return -1; }
    
    // Для RAM-FS просто очищаем предыдущие данные у файла
    if (ramfs) {
        struct fs_entry *entries = (struct fs_entry*)(fs_buffer + FS_BLOCK_SIZE);
        int idx = entry - entries;
        if (idx >=0 && idx < 64) memset(ram_file_data[idx], 0, sizeof(ram_file_data[idx]));
    } else {
        // Освободить старые блоки если есть
        uint32_t block = entry->first_block;
        while (block) {
            // Читаем блок
            if (disk_read(fs_start_lba + block * (FS_BLOCK_SIZE/512), FS_BLOCK_SIZE/512, fs_buffer + FS_BLOCK_SIZE) < 0) {
                console_printf("fs_write: failed to read old block %u\n", block);
                return -1;
            }
            struct fs_block *b = (struct fs_block*)(fs_buffer + FS_BLOCK_SIZE);
            uint32_t next = b->next;
            memset(b, 0, FS_BLOCK_SIZE);
            // Записываем очищенный блок
            if (disk_write(fs_start_lba + block * (FS_BLOCK_SIZE/512), FS_BLOCK_SIZE/512, fs_buffer + FS_BLOCK_SIZE) < 0) {
                console_printf("fs_write: failed to write cleared old block %u\n", block);
                return -1;
            }
            block = next;
        }
    }
    
    // Записать новые данные
    const uint8_t *src = (const uint8_t*)data;
    uint32_t remaining = size;
    uint32_t *last_next = &entry->first_block;

    if (ramfs) {
        struct fs_entry *entries = (struct fs_entry*)(fs_buffer + FS_BLOCK_SIZE);
        int idx = entry - entries;
        if (idx < 0 || idx >= 64) return -1;
        uint32_t write_len = remaining > 4092 ? 4092 : remaining;
        memcpy(ram_file_data[idx], src, write_len);
        entry->size = write_len;
        remaining = 0;
    } else {
        while (remaining) {
            // Найти свободный блок
            if (superblock->free_block >= superblock->blocks) return -1;
            uint32_t new_block = superblock->free_block++;
            
            // Подготовить блок
            struct fs_block *b = (struct fs_block*)(fs_buffer + FS_BLOCK_SIZE);
            uint32_t chunk = remaining > 4092 ? 4092 : remaining;
            memcpy(b->data, src, chunk);
            src += chunk;
            remaining -= chunk;
            
            // Связать блоки
            *last_next = new_block;
            last_next = &b->next;
            b->next = 0;
            
            // Записать блок на диск
            if (disk_write(fs_start_lba + new_block * (FS_BLOCK_SIZE/512), FS_BLOCK_SIZE/512, fs_buffer + FS_BLOCK_SIZE) < 0) {
                console_printf("fs_write: failed to write new block %u\n", new_block);
                return -1;
            }
        }
    }
    
    entry->size = size;
    
    // Записать обновленную таблицу файлов (если не RAM-FS)
    if (!ramfs) {
        if (disk_write(fs_start_lba + 1, FS_BLOCK_SIZE/512, fs_buffer + FS_BLOCK_SIZE) < 0) {
            console_printf("fs_write: failed to write file table after write\n");
            return -1;
        }
        
        // Обновить суперблок
        if (disk_write(fs_start_lba, 1, fs_buffer) < 0) {
            console_printf("fs_write: failed to write superblock after write\n");
            return -1;
        }
    }
    return 0;
}

// Прочитать данные из файла
int fs_read(const char *name, void *buf, uint32_t size) {
    if (!fs_initialized) {
        if (fs_init(0) < 0) return -1;
    }

    // Для RAM-FS не нужно читать таблицу с диска
    if (!ramfs) {
        if (disk_read(fs_start_lba + 1, FS_BLOCK_SIZE/512, fs_buffer + FS_BLOCK_SIZE) < 0) {
            return -1;
        }
    }
    
    struct fs_entry *entry = fs_find_entry(name);
    if (!entry) return -1;

    if (ramfs) {
        // В RAM-FS данные хранятся напрямую в ram_file_data
        struct fs_entry *entries = (struct fs_entry*)(fs_buffer + FS_BLOCK_SIZE);
        int idx = entry - entries;
        if (idx < 0 || idx >= 64) return -1;
        uint32_t read_len = size < entry->size ? size : entry->size;
        memcpy(buf, ram_file_data[idx], read_len);
        return read_len;
    }
    
    uint8_t *dst = (uint8_t*)buf;
    uint32_t remaining = size < entry->size ? size : entry->size;
    uint32_t block = entry->first_block;
    
    while (remaining && block) {
        // Читаем блок с диска
        if (disk_read(fs_start_lba + block * 8, 8, fs_buffer + FS_BLOCK_SIZE) < 0) {
            return -1;
        }
        
        struct fs_block *b = (struct fs_block*)(fs_buffer + FS_BLOCK_SIZE);
        uint32_t chunk = remaining > 4092 ? 4092 : remaining;
        memcpy(dst, b->data, chunk);
        dst += chunk;
        remaining -= chunk;
        block = b->next;
    }
    
    return size - remaining;
}

// Вывести список файлов
void fs_dir(void) {
    if (!superblock || superblock->magic != FS_MAGIC) return;

    // Обновим таблицу файлов из диска, если используем реальный диск
    if (!ramfs) {
        if (disk_read(fs_start_lba + 1, FS_BLOCK_SIZE/512, fs_buffer + FS_BLOCK_SIZE) < 0) {
            console_printf("fs_dir: failed to read file table\n");
            return;
        }
    }

    struct fs_entry *entries = (struct fs_entry*)(fs_buffer + FS_BLOCK_SIZE);
    console_printf("Files:\n");
    
    for (int i = 0; i < 64; i++) {
        if (entries[i].flags) {
            uint64_t created = entries[i].created;
            uint32_t sec = created & 0xFF;
            uint32_t min = (created >> 8) & 0xFF;
            uint32_t hour = (created >> 16) & 0xFF;
            uint32_t day = (created >> 24) & 0xFF;
            uint32_t month = (created >> 32) & 0xFF;
            uint32_t year = created >> 40;
            
            console_printf("%s - %d bytes - %04d-%02d-%02d %02d:%02d:%02d\n",
                entries[i].name, entries[i].size,
                year, month, day, hour, min, sec);
        }
    }
}