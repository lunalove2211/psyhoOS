// Single, consistent filesystem header for PsychoZ-OS
#ifndef PSYCHOZ_FS_H
#define PSYCHOZ_FS_H

#include <stdint.h>
#include <stddef.h>

#define FS_MAGIC 0x505A4F53u /* 'PZOS' */
#define FS_BLOCK_SIZE 4096
#define FS_MAX_FILENAME 32
#define FS_ENTRY_SIZE 64

// On-disk superblock (first block of the FS)
struct fs_superblock {
    uint32_t magic;
    uint32_t blocks;
    uint32_t free_block;
    uint32_t block_size;
    uint8_t reserved[512 - 16];
};

// File entry (in-memory/on-disk representation)
struct fs_entry {
    char     name[FS_MAX_FILENAME];
    uint32_t size;
    uint64_t created;
    uint32_t first_block;
    uint8_t  flags;
    uint8_t  reserved[15];
};

// Data block
struct fs_block {
    uint32_t next;
    uint8_t  data[FS_BLOCK_SIZE - 4];
};

/* Public filesystem API - signatures match implementations in kernel/fs.c */
int fs_init(uint32_t size_mb);
int fs_format(void);
struct fs_entry *fs_find_entry(const char *name);
int fs_create(const char *name);
int fs_delete(const char *name);
int fs_write(const char *name, const void *data, uint32_t size);
int fs_read(const char *name, void *buf, uint32_t size);
void fs_dir(void);

#endif /* PSYCHOZ_FS_H */