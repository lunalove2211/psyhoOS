#include <stddef.h>

// Function declarations
char* strchr(const char* str, int c);
size_t strlen(const char* str);
int strcmp(const char* s1, const char* s2);
void* memmove(void* dest, const void* src, size_t n);
char* strtok(char* str, const char* delim);
void* memset(void* s, int c, size_t n);
void* memcpy(void* dest, const void* src, size_t n);
char* strncpy(char* dest, const char* src, size_t n);
int memcmp(const void* s1, const void* s2, size_t n);

// Function implementations
char* strchr(const char* str, int c) {
    while (*str != '\0') {
        if (*str == (char)c) {
            return (char*)str;
        }
        str++;
    }
    return NULL;
}

size_t strlen(const char* str) {
    size_t len = 0;
    while (str[len] != '\0') {
        len++;
    }
    return len;
}

int strcmp(const char* s1, const char* s2) {
    while (*s1 && (*s1 == *s2)) {
        s1++;
        s2++;
    }
    return *(unsigned char*)s1 - *(unsigned char*)s2;
}

void* memmove(void* dest, const void* src, size_t n) {
    unsigned char* d = dest;
    const unsigned char* s = src;
    
    if (d < s) {
        // Copy forwards if dest is before src
        for (size_t i = 0; i < n; i++) {
            d[i] = s[i];
        }
    } else if (d > s) {
        // Copy backwards if dest is after src
        for (size_t i = n; i != 0; i--) {
            d[i-1] = s[i-1];
        }
    }
    
    return dest;
}

char* strtok(char* str, const char* delim) {
    static char* last = NULL;
    
    if (str) {
        last = str;
    } else if (!last) {
        return NULL;
    }
    
    // Skip leading delimiters
    while (*last && strchr(delim, *last)) {
        last++;
    }
    
    if (*last == '\0') {
        return NULL;
    }
    
    char* token = last;
    
    // Find end of token
    while (*last && !strchr(delim, *last)) {
        last++;
    }
    
    if (*last) {
        *last = '\0';
        last++;
    }
    
    return token;
}

void* memset(void* s, int c, size_t n) {
    unsigned char* p = s;
    while (n--) {
        *p++ = (unsigned char)c;
    }
    return s;
}

void* memcpy(void* dest, const void* src, size_t n) {
    unsigned char* d = dest;
    const unsigned char* s = src;
    while (n--) {
        *d++ = *s++;
    }
    return dest;
}

char* strncpy(char* dest, const char* src, size_t n) {
    size_t i;
    for (i = 0; i < n && src[i]; i++) {
        dest[i] = src[i];
    }
    for (; i < n; i++) {
        dest[i] = '\0';
    }
    return dest;
}

int memcmp(const void* s1, const void* s2, size_t n) {
    const unsigned char* p1 = s1;
    const unsigned char* p2 = s2;
    while (n--) {
        if (*p1 != *p2) {
            return *p1 - *p2;
        }
        p1++;
        p2++;
    }
    return 0;
}