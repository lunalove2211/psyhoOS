/*
 * main.c
 * Kernel entry for PsychoZ-OS
 * Simple console initialization and shell loop.
 */

#include <stdint.h>
#include "console.h"
#include "shell.h"
#include "drivers/block_interface.h"
#include "fs.h"

// Прототип, вызываемый из boot.s
void kernel_main(void *mb_info);

// Версия ОС
const char *OS_VERSION = "ASTRA-OS v2.0 (PSYHOZ lab)";

static inline void outb(unsigned short port, unsigned char val) {
    asm volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
}

void kernel_main(void *mb_info) {
    (void)mb_info; // пока не используем multiboot-info

    // Early serial init and debug print so we can capture startup logs
    // Initialize COM1 (0x3F8) for basic serial output (38400 8N1)
    outb(0x3F8+1, 0x00); // disable all interrupts
    outb(0x3F8+3, 0x80); // enable DLAB (set baud rate divisor)
    outb(0x3F8+0, 0x03); // divisor low byte (38400)
    outb(0x3F8+1, 0x00); // divisor high byte
    outb(0x3F8+3, 0x03); // 8 bits, no parity, one stop bit
    outb(0x3F8+2, 0xC7); // FIFO, 14 bytes
    outb(0x3F8+4, 0x0B); // IRQs enabled, RTS/DSR set

    // send a quick banner
    const char *b = "[kernel] enter\n";
    for (const char *p = b; *p; p++) outb(0x3F8, *p);

    console_init();
    console_clear();

    // === Storage subsystem init ===
    console_printf("[*] Initializing filesystem...\n");
    if (fs_init(0) < 0) {
        console_printf("[ERR] fs_init failed!\n");
    } else {
        console_printf("[OK] fs_init\n");
    }

    console_printf("\n");
    console_printf("Welcome to PSYHOZ lab x ASTRA-OS v2.0\n");
    console_printf("Specialized system for cosmology reconnaissance and parallel-world analysis.\n");
    console_printf("Type 'help' for available reconnaissance commands.\n");
    console_printf("\n");

    /* Longer startup animation and final message "Loading successful" */
    const char *spinner = "|/-\\";
    console_printf("Loading: ");
    for (int i = 0; i < 80; ++i) {
        char ch = spinner[i % 4];
        console_putc(ch);
        /* slower busy-wait to make animation visible */
        for (volatile unsigned long d = 0; d < 6000000UL; ++d) { asm volatile (""); }
        console_putc('\b');
    }
    console_printf("Load successful\n\n");
    /* Show information automatically right after the welcome message */
    console_printf("PSYHOZ lab - ASTRA-OS v2.0\n");
    console_printf("Specialized cosmology reconnaissance system\n");
    console_printf("Focus: multiverse analysis, quantum-relativistic modeling, and signal scouting.\n\n");
    console_printf("System status: ready for asynchronous exploration tasks.\n\n");

    // Запуск командной оболочки
    shell_loop();

    // Если shell вышел — засыпать
    for (;;) {
        asm volatile ("hlt");
    }
}
