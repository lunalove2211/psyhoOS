#include "rtc.h"

static inline unsigned char inb(unsigned short port) {
    unsigned char ret;
    asm volatile ("inb %1, %0" : "=a" (ret) : "Nd" (port));
    return ret;
}

static inline void outb(unsigned short port, unsigned char val) {
    asm volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
}

static unsigned char cmos_read(unsigned char reg) {
    outb(0x70, reg);
    return inb(0x71);
}

static unsigned char bcd_to_bin(unsigned char val) {
    return (val & 0x0F) + ((val >> 4) * 10);
}

void rtc_get_time(struct rtc_time *t) {
    // Read RTC repeatedly until we get two consistent reads
    unsigned char sec, min, hour, day, month, year, regB;
    unsigned char sec2, min2, hour2, day2, month2, year2;
    do {
        // wait for update-in-progress to be clear
        while (cmos_read(0x0A) & 0x80);
        sec = cmos_read(0x00);
        min = cmos_read(0x02);
        hour = cmos_read(0x04);
        day = cmos_read(0x07);
        month = cmos_read(0x08);
        year = cmos_read(0x09);
        regB = cmos_read(0x0B);

        // read again
        while (cmos_read(0x0A) & 0x80);
        sec2 = cmos_read(0x00);
        min2 = cmos_read(0x02);
        hour2 = cmos_read(0x04);
        day2 = cmos_read(0x07);
        month2 = cmos_read(0x08);
        year2 = cmos_read(0x09);
    } while (sec != sec2 || min != min2 || hour != hour2 || day != day2 || month != month2 || year != year2);

    int is_bcd = ! (regB & 0x04);
    if (is_bcd) {
        sec = bcd_to_bin(sec);
        min = bcd_to_bin(min);
        hour = bcd_to_bin(hour);
        day = bcd_to_bin(day);
        month = bcd_to_bin(month);
        year = bcd_to_bin(year);
    }

    // CMOS year is two-digit; assume 2000-2099
    t->sec = sec;
    t->min = min;
    t->hour = hour;
    t->day = day;
    t->month = month;
    t->year = 2000 + year;
}
