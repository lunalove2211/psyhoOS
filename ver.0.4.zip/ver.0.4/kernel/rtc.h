#ifndef RTC_H
#define RTC_H

#include <stdint.h>

struct rtc_time {
    uint8_t sec;
    uint8_t min;
    uint8_t hour;
    uint8_t day;
    uint8_t month;
    uint16_t year;
};

void rtc_get_time(struct rtc_time *t);

#endif // RTC_H
