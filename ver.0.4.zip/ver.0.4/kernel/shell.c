/*
 * shell.c
 * Простейшая командная оболочка PsychoZ-OS
 * Читает ввод с клавиатуры, обрабатывает команды и вызывает команды из commands.c
 */

#include <stdint.h>
#include <stddef.h>
#include "console.h"
#include "commands.h"

// Минимальная реализация чтения клавиатуры через порт 0x60 (скан-коды set 1)
static inline uint8_t inb(uint16_t port) {
    uint8_t ret;
    asm volatile ("inb %1, %0" : "=a" (ret) : "Nd" (port));
    return ret;
}

// Небольшая таблица для скан-кодов -> ASCII (без учёта Shift/AltGr)
// Scancode set 1 -> ASCII without shift
static const char scancode_map[128] = {
    0, 27, '1','2','3','4','5','6','7','8','9','0','-','=', '\b', '\t',
    'q','w','e','r','t','y','u','i','o','p','[',']','\n', 0,
    'a','s','d','f','g','h','j','k','l',';','\'', '`', 0,
    '\\','z','x','c','v','b','n','m',',','.','/', 0, '*', 0, ' '
};

// Shifted equivalents for keys that change when shift is held
static const char scancode_map_shift[128] = {
    0, 27, '!','@','#','$','%','^','&','*','(',')','_','+', '\b', '\t',
    'Q','W','E','R','T','Y','U','I','O','P','{','}','\n', 0,
    'A','S','D','F','G','H','J','K','L',':','"','~', 0,
    '|','Z','X','C','V','B','N','M','<','>','?', 0, '*', 0, ' '
};

// Получить символ, ожидая скан-код
static char get_char_blocking() {
    int shift = 0;
    while (1) {
        uint8_t status = inb(0x64);
        if (status & 1) {
            uint8_t sc = inb(0x60);
            // handle key release for shift
            if (sc == 0x2A || sc == 0x36) {
                // shift pressed (make)
                shift = 1;
                continue;
            }
            if (sc == 0xAA || sc == 0xB6) {
                // shift released (break)
                shift = 0;
                continue;
            }
            if (sc & 0x80) continue; // other key release
            if (sc < 128) {
                char c = shift ? scancode_map_shift[sc] : scancode_map[sc];
                if (c) return c;
            }
        }
    }
}
// Key event codes for special keys
enum {
    KEY_NONE = 0,
    KEY_CHAR = 1,
    KEY_UP = 1001,
    KEY_DOWN = 1002,
    KEY_LEFT = 1003,
    KEY_RIGHT = 1004,
};

// Return: if >0 and <256 => character; if >=1000 => special key code
static int get_key_event() {
    static int shift = 0;
    static int capslock = 0;
    while (1) {
        uint8_t status = inb(0x64);
        if (!(status & 1)) continue;
        uint8_t sc = inb(0x60);
        
        // handle shift make/break
        if (sc == 0x2A || sc == 0x36) { shift = 1; continue; }
        if (sc == 0xAA || sc == 0xB6) { shift = 0; continue; }
        
        // handle capslock
        if (sc == 0x3A) { capslock = !capslock; continue; }

        // Handle extended prefix 0xE0 for arrow keys
        if (sc == 0xE0) {
            // read the next scancode
            // wait for next byte
            while (!(inb(0x64) & 1));
            uint8_t sc2 = inb(0x60);
            // ignore break codes
            if (sc2 & 0x80) continue;
            if (sc2 == 0x48) return KEY_UP;
            if (sc2 == 0x50) return KEY_DOWN;
            if (sc2 == 0x4B) return KEY_LEFT;
            if (sc2 == 0x4D) return KEY_RIGHT;
            continue;
        }

        if (sc & 0x80) continue; // key release
        // check arrow keys without E0 (some BIOSes)
        if (sc == 0x48) return KEY_UP;
        if (sc == 0x50) return KEY_DOWN;
        if (sc == 0x4B) return KEY_LEFT;
        if (sc == 0x4D) return KEY_RIGHT;

        if (sc < 128) {
            char c = scancode_map[sc];
            if (c) {
                // For letters (a-z, A-Z), apply CAPSLOCK XOR SHIFT
                if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
                    if (capslock ^ shift) {
                        // Toggle case
                        c ^= 0x20;
                    }
                } else if (shift) {
                    // For other characters, just use shift map
                    c = scancode_map_shift[sc];
                }
                return (int)(unsigned char)c;
            }
        }
    }
}

// shell_readline is implemented below with history and arrow-key support
void shell_readline(char *buf, size_t buflen) {
    // simple history buffer
    static char history[16][256];
    static int history_count = 0;
    static int history_pos = 0;

    size_t pos = 0;
    int hist_index = history_count; // position in history when editing

    while (1) {
        int ev = get_key_event();
        if (ev == KEY_UP) {
            if (history_count == 0) continue;
            if (hist_index > 0) hist_index--;
            // replace current buffer with history[hist_index]
            // erase current displayed chars
            while (pos > 0) { console_putc('\b'); console_putc(' '); console_putc('\b'); pos--; }
            // copy
            const char *h = history[hist_index];
            size_t i = 0;
            while (h[i] && i + 1 < buflen) { buf[i] = h[i]; console_putc(h[i]); i++; }
            pos = i; buf[pos] = '\0';
        } else if (ev == KEY_DOWN) {
            if (history_count == 0) continue;
            if (hist_index < history_count - 1) hist_index++; else { hist_index = history_count; }
            while (pos > 0) { console_putc('\b'); console_putc(' '); console_putc('\b'); pos--; }
            if (hist_index == history_count) { buf[0] = '\0'; pos = 0; }
            else {
                const char *h = history[hist_index];
                size_t i = 0;
                while (h[i] && i + 1 < buflen) { buf[i] = h[i]; console_putc(h[i]); i++; }
                pos = i; buf[pos] = '\0';
            }
        } else if (ev == KEY_LEFT) {
            // optional: implement cursor left (not shifting insert)
            // ignore for now
        } else if (ev == KEY_RIGHT) {
            // ignore
        } else if (ev == '\r' || ev == '\n') {
            console_putc('\n');
            buf[pos] = '\0';
            // save to history
            if (pos > 0) {
                int idx = history_count % 16;
                // copy
                int j; for (j = 0; j < (int)pos && j < 255; j++) history[idx][j] = buf[j];
                history[idx][j] = '\0';
                history_count = (history_count < 16) ? history_count + 1 : history_count;
            }
            return;
        } else if (ev == '\b') {
            if (pos > 0) {
                pos--;
                console_putc('\b'); console_putc(' '); console_putc('\b');
            }
        } else if (ev > 0 && ev < 256) {
            char c = (char)ev;
            if (pos + 1 < buflen) {
                buf[pos++] = c;
                buf[pos] = '\0';
                console_putc(c);
            }
        }
    }
}

void shell_loop() {
    char line[256];
    for (;;) {
        console_printf("ASTRA> ");
        shell_readline(line, sizeof(line));
        if (line[0] == '\0') continue;
        if (command_dispatch(line) == 1) {
            // команда exit — выйти из shell
            break;
        }
    }
}
