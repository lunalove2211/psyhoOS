#ifndef SHELL_H
#define SHELL_H

void shell_loop(void);
void shell_readline(char *buf, size_t buflen);

#endif // SHELL_H
