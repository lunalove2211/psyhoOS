// Simple flat file system for OS
#include "../drivers/block_interface.h"
#include <stdint.h>
#include <stddef.h>
extern void *memset(void *s, int c, size_t n);
extern char *strncpy(char *dest, const char *src, size_t n);
extern int strcmp(const char *s1, const char *s2);
extern int printf(const char *fmt, ...);

#define FS_MAGIC 0x50535948
#define FS_MAX_FILES 64
#define FS_MAX_FILENAME 32
#define FS_BLOCK_SIZE 4096
#define FS_ENTRY_SIZE 64

struct fs_entry {
    char name[FS_MAX_FILENAME];
    uint32_t size;
    uint32_t first_block;
    uint8_t flags;
    uint8_t reserved[FS_ENTRY_SIZE-40];
};

struct fs_superblock {
    uint32_t magic;
    uint32_t blocks;
    uint32_t free_block;
    uint32_t block_size;
    uint8_t reserved[FS_BLOCK_SIZE-16];
};

static struct fs_superblock superblock;
static struct fs_entry file_table[FS_MAX_FILES];
static int fs_loaded = 0;

static int fs_load(void) {
    block_read(0, &superblock, 8); // 8*512=4096
    if (superblock.magic != FS_MAGIC) return -1;
    block_read(8, file_table, 8); // file table
    fs_loaded = 1;
    return 0;
}

int fs_init(void) {
    if (fs_load() == 0) return 0;
    memset(&superblock, 0, sizeof(superblock));
    superblock.magic = FS_MAGIC;
    superblock.blocks = 2048;
    superblock.free_block = 16;
    superblock.block_size = FS_BLOCK_SIZE;
    memset(file_table, 0, sizeof(file_table));
    block_write(0, &superblock, 8);
    block_write(8, file_table, 8);
    fs_loaded = 1;
    return 0;
}

int fs_create(const char *name) {
    if (!fs_loaded) fs_init();
    for (int i = 0; i < FS_MAX_FILES; ++i) {
        if (file_table[i].flags && strcmp(file_table[i].name, name) == 0) return -1;
    }
    for (int i = 0; i < FS_MAX_FILES; ++i) {
        if (!file_table[i].flags) {
            strncpy(file_table[i].name, name, FS_MAX_FILENAME-1);
            file_table[i].size = 0;
            file_table[i].first_block = 0;
            file_table[i].flags = 1;
            block_write(8, file_table, 8);
            return 0;
        }
    }
    return -1;
}

int fs_delete(const char *name) {
    if (!fs_loaded) fs_init();
    for (int i = 0; i < FS_MAX_FILES; ++i) {
        if (file_table[i].flags && strcmp(file_table[i].name, name) == 0) {
            file_table[i].flags = 0;
            block_write(8, file_table, 8);
            return 0;
        }
    }
    return -1;
}

int fs_write(const char *name, const void *data, uint32_t size) {
    if (!fs_loaded) fs_init();
    for (int i = 0; i < FS_MAX_FILES; ++i) {
        if (file_table[i].flags && strcmp(file_table[i].name, name) == 0) {
            uint32_t block = superblock.free_block++;
            block_write(block, data, (size+511)/512);
            file_table[i].first_block = block;
            file_table[i].size = size;
            block_write(8, file_table, 8);
            block_write(0, &superblock, 8);
            return 0;
        }
    }
    return -1;
}

int fs_read(const char *name, void *data, uint32_t size) {
    if (!fs_loaded) fs_init();
    for (int i = 0; i < FS_MAX_FILES; ++i) {
        if (file_table[i].flags && strcmp(file_table[i].name, name) == 0) {
            block_read(file_table[i].first_block, data, (size+511)/512);
            return 0;
        }
    }
    return -1;
}

void fs_dir(void) {
    if (!fs_loaded) fs_init();
    for (int i = 0; i < FS_MAX_FILES; ++i) {
        if (file_table[i].flags) {
            printf("%s %u bytes\n", file_table[i].name, file_table[i].size);
        }
    }
}
