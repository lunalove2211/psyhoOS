#!/bin/bash
# Создать USB raw image с двумя разделами:
#   partition 1: FAT32, содержит GRUB + /boot/kernel.elf (загрузочный)
#   partition 2: ext2 (или raw), используется для хранения данных (disk partition)
# Требования: запуск в Linux/WSL с sudo, установлены: parted, losetup, kpartx, mkfs.vfat, mkfs.ext2, grub-install, xorriso, rsync

set -euo pipefail
ROOT_DIR=$(cd "$(dirname "$0")/.." && pwd)
IMG="${ROOT_DIR}/usb.img"
ISO="${ROOT_DIR}/psychoz.iso"
SIZE_MB=256
BOOT_LABEL="PSYHOZ_BOOT"
DATA_LABEL="PSYHOZ_DATA"

if [ ! -f "$ISO" ]; then
  echo "ERROR: $ISO not found. Build the ISO first (make iso in project root)."
  exit 1
fi

echo "Creating blank image: $IMG (${SIZE_MB}MB)"
truncate -s ${SIZE_MB}M "$IMG"

echo "Partitioning image (MBR, 2 partitions)"
parted --script "$IMG" mklabel msdos
# partition1: 1MiB-64MiB (FAT)
parted --script "$IMG" mkpart primary fat32 1MiB 64MiB
parted --script "$IMG" set 1 boot on
# partition2: remainder
parted --script "$IMG" mkpart primary ext2 64MiB 100%

# setup loop device with partitions
LOOP=$(losetup --show -fP "$IMG")
if [ -z "$LOOP" ]; then
  echo "losetup failed"
  exit 1
fi
echo "Loop device: $LOOP"
PART1=${LOOP}p1
PART2=${LOOP}p2

echo "Formatting partitions"
mkfs.vfat -n "$BOOT_LABEL" "$PART1"
mkfs.ext2 -L "$DATA_LABEL" "$PART2"

# mount partitions
MNT_BOOT=$(mktemp -d)
MNT_ISO=$(mktemp -d)
MNT_TMP=$(mktemp -d)
mount "$PART1" "$MNT_BOOT"
mount -o loop "$ISO" "$MNT_ISO"

echo "Copying ISO contents to boot partition"
rsync -aH --delete "$MNT_ISO/" "$MNT_BOOT/"

# Ensure /boot/grub exists
mkdir -p "$MNT_BOOT/boot/grub"

echo "Installing GRUB (i386-pc) into image"
# grub-install needs a block device (not partition) but with loop device it's fine
grub-install --target=i386-pc --boot-directory="$MNT_BOOT/boot" --recheck --no-floppy --root-directory="$MNT_BOOT" "$LOOP"

sync
umount "$MNT_ISO"
umount "$MNT_BOOT"
rm -rf "$MNT_ISO" "$MNT_BOOT"

# detach loop
losetup -d "$LOOP"

echo "USB image created: $IMG"

echo "You can test it in QEMU with:"
echo "  qemu-system-i386 -hda $IMG -m 512 -serial stdio -no-reboot -monitor none"

echo "To write to a real USB device (DANGEROUS!), run as admin/root and use dd or Rufus in DD mode."

exit 0
