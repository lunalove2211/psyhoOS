#!/bin/sh
set -eu
ISO="psychoz.iso"
RISO="psychoz-rufus.iso"

if [ ! -f "$ISO" ]; then
  echo "Error: $ISO not found. Build the ISO first (make iso)." >&2
  exit 2
fi

cp -f "$ISO" "$RISO"

echo "Created $RISO (copy of $ISO)."

echo "Note: this script intentionally does NOT apply isohybrid."
echo "Rufus 'ISO Image' mode expects a standard El Torito ISO; use Rufus ISO mode to write $RISO."

echo "If Rufus still shows an empty GRUB menu, try these steps:" 
echo " - Ensure Rufus is set to 'ISO Image' mode (not DD)."
echo " - If problems persist, run 'make iso' then inspect psychoz_contents.txt to verify grub.cfg is present."
