#!/bin/sh
# Automated test for OS block and FS layer
set -e

IMG=disk_test.img
SECTORS=204800
BS=512

# Create blank image
qemu-img create -f raw $IMG $((SECTORS*BS))

# Boot OS in QEMU with test image as primary disk
qemu-system-x86_64 -drive file=$IMG,format=raw,if=virtio -serial stdio -nographic -m 256M -kernel build/kernel.elf <<EOF
CREATE test.txt
WRITE test.txt HelloWorld
READ test.txt
DIR
DELETE test.txt
DIR
EOF

# Check image for changes
hexdump -C $IMG | head -40

echo "Test completed."
